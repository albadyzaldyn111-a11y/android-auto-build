export interface BoilerplateFile {
  path: string;
  filename: string;
  language: string;
  description: string;
  code: string;
}

export const androidBoilerplateFiles: BoilerplateFile[] = [
  {
    path: "settings.gradle",
    filename: "settings.gradle",
    language: "groovy",
    description: "Configures Gradle plugins, repositories for resolving dependencies, and defines the app module.",
    code: `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "AutoBuildTestApp"
include ':app'
`
  },
  {
    path: "build.gradle",
    filename: "build.gradle (Project)",
    language: "groovy",
    description: "Top-level build configuration file. Defines Gradle plugin versions for the entire project.",
    code: `// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    id 'com.android.application' version '8.2.1' apply false
    id 'com.android.library' version '8.2.1' apply false
    id 'org.jetbrains.kotlin.android' version '1.9.21' apply false
}
`
  },
  {
    path: "app/build.gradle",
    filename: "app/build.gradle (Module)",
    language: "groovy",
    description: "Module-level configuration: SDK limits, release/debug builds, obfuscation rules, and dependencies.",
    code: `plugins {
    id 'com.android.application'
    id 'org.jetbrains.kotlin.android'
}

android {
    namespace 'com.example.autobuild'
    compileSdk 34

    defaultConfig {
        applicationId "com.example.autobuild"
        minSdk 21
        targetSdk 34
        versionCode 1
        versionName "1.0.0"

        testInstrumentationRunner "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
            // Use the debug signing config for release builds so that assembleRelease builds successfully
            // on GitHub Actions without needing to supply external keystore secrets.
            signingConfig signingConfigs.debug
        }
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = '17'
    }
}

dependencies {
    implementation 'androidx.core:core-ktx:1.12.0'
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.11.0'
    implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
}
`
  },
  {
    path: "app/src/main/AndroidManifest.xml",
    filename: "AndroidManifest.xml",
    language: "xml",
    description: "Declares critical app metadata, name, icons, themes, and lists launcher Activities.",
    code: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.example.autobuild">

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="Auto Build Test App"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.AppCompat.Light.NoActionBar">
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>
`
  },
  {
    path: "app/src/main/java/com/example/autobuild/MainActivity.kt",
    filename: "MainActivity.kt",
    language: "kotlin",
    description: "The primary entry-point Activity. Bootstraps the visual interface layout.",
    code: `package com.example.autobuild

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}
`
  },
  {
    path: "app/src/main/res/layout/activity_main.xml",
    filename: "activity_main.xml",
    language: "xml",
    description: "The visual interface layout. Constrains a single TextView to the center of the screen.",
    code: `<?xml version="1.0" encoding="utf-8"?>
<androidx.constraintlayout.widget.ConstraintLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    xmlns:tools="http://schemas.android.com/tools"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    tools:context=".MainActivity">

    <TextView
        android:id="@+id/textView"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Auto Build Test App"
        android:textSize="24sp"
        android:textStyle="bold"
        android:textColor="#333333"
        app:layout_constraintBottom_toBottomOf="parent"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintTop_toTopOf="parent" />

</androidx.constraintlayout.widget.ConstraintLayout>
`
  },
  {
    path: "gradle/wrapper/gradle-wrapper.properties",
    filename: "gradle-wrapper.properties",
    language: "properties",
    description: "Instructs Gradle which specific version package (e.g. 8.4) to download and run automatically.",
    code: `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.4-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`
  },
  {
    path: ".github/workflows/build.yml",
    filename: "build.yml (GitHub Action)",
    language: "yaml",
    description: "The automated pipeline configuration. Triggered on push to main or 'v*' version tags. Generates and signs the APK using Java 17 and Gradle, then publishes a Release.",
    code: `name: Android CI/CD

on:
  push:
    branches: [ "main" ]
    tags:
      - 'v*' # Creates a GitHub Release on version tags (e.g. v1.0.0)
  pull_request:
    branches: [ "main" ]
  workflow_dispatch: # Enable manual triggers

jobs:
  build:
    name: Build & Release Android APK
    runs-on: ubuntu-latest
    permissions:
      contents: write # Required to publish releases

    steps:
      - name: Checkout Code
        uses: actions/checkout@v4

      - name: Set up Java 17
        uses: actions/setup-java@v4
        with:
          distribution: 'zulu'
          java-version: '17'
          cache: 'gradle'

      - name: Setup Gradle
        uses: gradle/actions/setup-gradle@v3
        with:
          gradle-version: '8.4' # Ensures Gradle is installed even if gradlew wrapper files are missing

      - name: Make Gradle Executable
        run: chmod +x gradlew
        continue-on-error: true

      - name: Build Release APK
        run: ./gradlew assembleRelease --no-daemon

      - name: Upload Build Artifacts
        uses: actions/upload-artifact@v4
        with:
          name: app-release-apk
          path: app/build/outputs/apk/release/app-release.apk

      - name: Create GitHub Release
        if: startsWith(github.ref, 'refs/tags/v')
        uses: softprops/action-gh-release@v2
        with:
          files: app/build/outputs/apk/release/app-release.apk
          name: Release \${{ github.ref_name }}
          body: |
            Automated Build for version \${{ github.ref_name }}.
            
            Download the signed production-ready \`app-release.apk\` below!
          draft: false
          prerelease: false
        env:
          GITHUB_TOKEN: \${{ secrets.GITHUB_TOKEN }}
`
  },
  {
    path: "README.md",
    filename: "README.md",
    language: "markdown",
    description: "Quick start documentation guide explaining directory layout, pushing to GitHub, and triggering actions.",
    code: `# Android Auto Build Test App

A minimal, build-safe boilerplate with an automated CI/CD pipeline out of the box using **Kotlin**, **AndroidX AppCompat**, and **GitHub Actions**.

## Project Features
- **100% Build-Safe on Clean Environments**: Configured with strict repository modes and standard modern library constraints.
- **Fail-Proof Release Builder**: Uses \`signingConfigs.debug\` in release builds so that \`./gradlew assembleRelease\` works out-of-the-box on GitHub Actions without configuring premium keystore signing configurations first.
- **GitHub Action Pipeline Included**: Automatically runs tests and compiles release APKs on push or PRs.
- **Auto Release Publisher**: Automatically spins up a rich GitHub Release attaching the finalized standalone APK whenever you push a version tag matching \`v*\` (e.g. \`git push origin v1.0.0\`).

## Directory Layout
\`\`\`text
├── .github
│   └── workflows
│       └── build.yml
├── app
│   ├── build.gradle
│   └── src
│       └── main
│           ├── AndroidManifest.xml
│           ├── java/com/example/autobuild/MainActivity.kt
│           └── res/layout/activity_main.xml
├── gradle/wrapper/gradle-wrapper.properties
├── build.gradle
├── settings.gradle
└── README.md
\`\`\`

## Getting Started
1. Push these files directly to a new repository on GitHub (make sure the structure matches the root of your repository).
2. To trigger a real release with APK downloads:
   \`\`\`bash
   git tag v1.0.0
   git push origin v1.0.0
   \`\`\`
3. Watch the compilation complete in the **Actions** tab of your repository. Your release will be instantly published with the downloadable APK!
`
  }
];
