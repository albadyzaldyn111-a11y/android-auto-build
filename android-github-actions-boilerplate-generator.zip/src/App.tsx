import { useState } from "react";
import { 
  Folder, 
  FileCode, 
  Terminal, 
  Copy, 
  Check, 
  Sliders, 
  Github, 
  Play, 
  RefreshCw, 
  CheckCircle2, 
  HelpCircle, 
  ExternalLink, 
  BookOpen, 
  Code2, 
  ChevronRight
} from "lucide-react";
import { androidBoilerplateFiles, BoilerplateFile } from "./boilerplateFiles";

export default function App() {
  const [appName, setAppName] = useState("Auto Build Test App");
  const [packageName, setPackageName] = useState("com.example.autobuild");
  const [minSdk, setMinSdk] = useState("21");
  const [targetSdk, setTargetSdk] = useState("34");
  const [selectedFileIndex, setSelectedFileIndex] = useState(0);
  const [copyStatus, setCopyStatus] = useState<string | null>(null);
  
  // Custom build simulation state
  const [simulationActive, setSimulationActive] = useState(false);
  const [simStep, setSimStep] = useState(0);
  const [simLogs, setSimLogs] = useState<string[]>([]);
  const [simCompleted, setSimCompleted] = useState(false);

  // Generate helper PascalCase name for settings gradle
  const sanitizedAppName = appName.replace(/[^a-zA-Z0-9]/g, "");
  const settingsGradleAppName = sanitizedAppName || "AutoBuildTestApp";

  // Customize file content dynamically based on developer inputs
  const getCustomizedContent = (file: BoilerplateFile): string => {
    let code = file.code;
    
    // settings.gradle customizations
    if (file.path === "settings.gradle") {
      code = code.replace(/rootProject\.name = "AutoBuildTestApp"/g, `rootProject.name = "${settingsGradleAppName}"`);
    }
    
    // app/build.gradle customizations
    if (file.path === "app/build.gradle") {
      code = code.replace(/namespace 'com\.example\.autobuild'/g, `namespace '${packageName}'`);
      code = code.replace(/applicationId "com\.example\.autobuild"/g, `applicationId "${packageName}"`);
      code = code.replace(/minSdk \d+/g, `minSdk ${minSdk}`);
      code = code.replace(/targetSdk \d+/g, `targetSdk ${targetSdk}`);
      code = code.replace(/compileSdk \d+/g, `compileSdk ${targetSdk}`);
    }
    
    // AndroidManifest.xml customizations
    if (file.path === "app/src/main/AndroidManifest.xml") {
      code = code.replace(/package="com\.example\.autobuild"/g, `package="${packageName}"`);
      code = code.replace(/android:label="Auto Build Test App"/g, `android:label="${appName}"`);
    }
    
    // MainActivity.kt customizations
    if (file.path === "app/src/main/java/com/example/autobuild/MainActivity.kt") {
      code = code.replace(/package com\.example\.autobuild/g, `package ${packageName}`);
    }
    
    // activity_main.xml customizations
    if (file.path === "app/src/main/res/layout/activity_main.xml") {
      code = code.replace(/android:text="Auto Build Test App"/g, `android:text="${appName}"`);
    }

    // README/instructions customizations
    if (file.path === "README.md") {
      code = code.replace(/Auto Build Test App/g, appName);
      code = code.replace(/com\.example\.autobuild/g, packageName);
    }
    
    return code;
  };

  // Get dynamic display path (adjusts Kotlin directory structures based on package name)
  const getDynamicPath = (file: BoilerplateFile): string => {
    if (file.path === "app/src/main/java/com/example/autobuild/MainActivity.kt") {
      const packagePath = packageName.replace(/\./g, "/");
      return `app/src/main/java/${packagePath}/MainActivity.kt`;
    }
    return file.path;
  };

  const currentFile = androidBoilerplateFiles[selectedFileIndex];
  const currentCode = getCustomizedContent(currentFile);
  const currentPath = getDynamicPath(currentFile);

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopyStatus(label);
    setTimeout(() => {
      setCopyStatus(null);
    }, 2000);
  };

  // Automated release action simulator
  const simulationSteps = [
    { label: "Triggering action...", duration: 600, log: "🚀 Workflow triggered via branch push [main]" },
    { label: "Setting up Ubuntu virtual machine...", duration: 800, log: "⚙️ Operating System: Ubuntu Latest x64 VM" },
    { label: "Checking out source code...", duration: 1000, log: "📥 Checking out repository code: git fetch & checkout" },
    { label: "Setting up Zulu OpenJDK 17...", duration: 1200, log: "☕ Setup Java Development Kit JDK 17 (zulu version 17.0.8)" },
    { label: "Initializing Gradle wrapper daemon...", duration: 1400, log: "🔧 Restoring caching for .gradle dependencies (found cached build)" },
    { label: "Running: ./gradlew assembleRelease...", duration: 2500, log: "⚙️ $ ./gradlew assembleRelease --no-daemon\n   > Task :app:preBuild UP-TO-DATE\n   > Task :app:compileReleaseKotlin\n   > Task :app:mergeReleaseAssets\n   > Task :app:processReleaseResources\n   > Task :app:compileReleaseJavaWithJavac\n   > Task :app:packageRelease" },
    { label: "Generating unsigned APK...", duration: 1250, log: "📦 Found output at: app/build/outputs/apk/release/app-release-unsigned.apk" },
    { label: "Applying debug signing-fallback keys...", duration: 1000, log: "✍️ Signing release build with keystore-fallback. Signed APK compiled." },
    { label: "Uploading artifact archive...", duration: 1000, log: "📤 Uploading artifact 'app-release-apk' (Size: 1.48 MB)" },
    { label: "Publishing secure GitHub Release tag...", duration: 1200, log: "🎉 Creating GitHub Release v1.0.0 & attaching signed app-release.apk to pipeline!" },
  ];

  const startBuildSimulation = async () => {
    if (simulationActive) return;
    setSimulationActive(true);
    setSimCompleted(false);
    setSimStep(0);
    setSimLogs([`⏳ CI/CD Pipeline Initialized at ${new Date().toLocaleTimeString()}`]);

    let stepIndex = 0;
    const runNextStep = () => {
      if (stepIndex < simulationSteps.length) {
        const step = simulationSteps[stepIndex];
        setSimStep(stepIndex);
        setSimLogs(prev => [...prev, step.log]);
        stepIndex++;
        setTimeout(runNextStep, step.duration);
      } else {
        setSimCompleted(true);
        setSimLogs(prev => [...prev, "✨ SUCCESS: GitHub Actions build finished beautifully with zero compilation errors! APK is certified active."]);
      }
    };

    setTimeout(runNextStep, 500);
  };

  // Generate automated quick-setup shell script for the developer's local shell
  const generateBashScript = (): string => {
    const packageFolder = packageName.replace(/\./g, "/");
    const scriptLines = [
      "#!/bin/bash",
      `# Automated folder setup & file writer for ${appName}`,
      "echo '⚙️ Crafting Android Repository directories...'",
      "mkdir -p .github/workflows",
      `mkdir -p app/src/main/java/${packageFolder}`,
      "mkdir -p app/src/main/res/layout",
      "mkdir -p gradle/wrapper",
      "",
    ];

    androidBoilerplateFiles.forEach(file => {
      const livePath = getDynamicPath(file);
      const liveContent = getCustomizedContent(file);
      // Escape single quotes and dollar signs for correct echoing
      const escapedContent = liveContent
        .replace(/\\/g, "\\\\")
        .replace(/'/g, "'\\''")
        .replace(/\$/g, "\\$");
        
      scriptLines.push(`echo 'Generating ${livePath}...'`);
      scriptLines.push(`cat << 'EOF' > ${livePath}`);
      scriptLines.push(liveContent);
      scriptLines.push("EOF");
      scriptLines.push("");
    });

    scriptLines.push("echo '✅ Android Workspace configured successfully!'");
    scriptLines.push("echo '💡 Next step: Push to a GitHub repository, tag it v1.0.0, and watch actions build!'");
    
    return scriptLines.join("\n");
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans select-none antialiased">
      {/* Header bar */}
      <header className="border-b border-slate-900 bg-slate-950/80 backdrop-blur-md sticky top-0 z-40 px-6 py-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-sky-500/10 rounded-lg border border-sky-450/20 text-sky-400">
              <Code2 className="h-6 w-6" id="hdr-logo-icon" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs px-2.5 py-0.5 rounded-full font-mono bg-sky-500/15 text-sky-400 border border-sky-400/10 font-bold uppercase tracking-wider">Kotlin + Actions</span>
              </div>
              <h1 className="text-xl font-bold tracking-tight text-white mt-0.5">Android GitHub Actions Boilerplate Generator</h1>
            </div>
          </div>
          
          <div className="flex items-center gap-3 text-sm font-mono text-slate-400 bg-slate-900/55 border border-slate-800/80 px-3.5 py-1.5 rounded-lg">
            <span>Compiler target:</span>
            <span className="text-emerald-400 font-semibold font-mono">JDK 17 + Gradle 8.4</span>
          </div>
        </div>
      </header>

      {/* Main Body Grid */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Side: Customize & Workspace Tree Structure */}
        <section className="lg:col-span-4 flex flex-col gap-6" id="customizer-panel">
          
          {/* Customizer config form */}
          <div className="bg-slate-900/45 border border-slate-800/60 rounded-2xl p-5 backdrop-blur-sm shadow-xl flex flex-col gap-4">
            <div className="flex items-center gap-2 border-b border-slate-800/80 pb-3">
              <Sliders className="h-5 w-5 text-sky-400" />
              <h2 className="text-sm font-semibold tracking-wide text-white uppercase">App Configurations</h2>
            </div>
            
            <div className="flex flex-col gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1.5 uppercase tracking-wide">App Target Name</label>
                <input
                  type="text"
                  value={appName}
                  onChange={(e) => setAppName(e.target.value || "Auto Build Test App")}
                  className="w-full bg-slate-950/80 border border-slate-800 focus:border-sky-500 rounded-xl px-4 py-2.5 text-sm text-slate-100 outline-none transition-all duration-200 shadow-inner"
                  placeholder="e.g. My Awesome App"
                  id="input-app-name"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1.5 uppercase tracking-wide">Kotlin Package Name</label>
                <input
                  type="text"
                  value={packageName}
                  onChange={(e) => setPackageName(e.target.value.toLowerCase().replace(/[^a-z0-0.]/g, "") || "com.example.autobuild")}
                  className="w-full bg-slate-950/80 border border-slate-800 focus:border-sky-500 rounded-xl px-4 py-2.5 text-sm font-mono text-slate-200 outline-none transition-all duration-200 shadow-inner"
                  placeholder="e.g. com.company.app"
                  id="input-package-name"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1.5 uppercase tracking-wide">Min SDK</label>
                  <select
                    value={minSdk}
                    onChange={(e) => setMinSdk(e.target.value)}
                    className="w-full bg-slate-950/80 border border-slate-805/80 focus:border-sky-500 rounded-xl px-3 py-2 text-sm text-slate-200 outline-none outline-0 cursor-pointer"
                    id="select-min-sdk"
                  >
                    <option value="21">API 21 (Lollipop)</option>
                    <option value="24">API 24 (Nougat)</option>
                    <option value="26">API 26 (Oreo)</option>
                    <option value="29">API 29 (Q)</option>
                    <option value="31">API 31 (S)</option>
                    <option value="33">API 33 (Tiramisu)</option>
                    <option value="34">API 34 (Upside Down Cake)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1.5 uppercase tracking-wide">Target SDK</label>
                  <select
                    value={targetSdk}
                    onChange={(e) => setTargetSdk(e.target.value)}
                    className="w-full bg-slate-950/80 border border-slate-805/80 focus:border-sky-500 rounded-xl px-3 py-2 text-sm text-slate-200 outline-none outline-0 cursor-pointer"
                    id="select-target-sdk"
                  >
                    <option value="31">API 31 (Android 12)</option>
                    <option value="33">API 33 (Android 13)</option>
                    <option value="34">API 34 (Android 14)</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="text-xs text-slate-400/90 border-t border-slate-800/80 pt-3 flex flex-col gap-1">
              <span className="flex items-center gap-1.5 text-sky-400 font-medium">
                <CheckCircle2 className="h-3.5 w-3.5" /> Out-of-the-box build safe.
              </span>
              <span>All changes automatically refresh below in the explorer and the launcher scripts!</span>
            </div>
          </div>

          {/* Directory Tree selector */}
          <div className="bg-slate-900/45 border border-slate-800/60 rounded-2xl p-5 backdrop-blur-sm flex-1 flex flex-col gap-4 shadow-xl">
            <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Folder className="h-5 w-5 text-amber-400" />
                <h2 className="text-sm font-semibold tracking-wide text-white uppercase">Project Files</h2>
              </div>
              <span className="text-[10px] bg-slate-800 text-slate-400 font-mono px-2 py-0.5 rounded">
                9 files mapped
              </span>
            </div>

            {/* Tree listing */}
            <div className="flex-1 flex flex-col gap-1 overflow-y-auto pr-1" id="workspace-tree">
              <div className="text-xs font-mono text-slate-400 py-1 select-none flex items-center gap-1">
                <span>📁 {settingsGradleAppName}</span>
              </div>
              
              {androidBoilerplateFiles.map((file, idx) => {
                const dynamicPath = getDynamicPath(file);
                const isSelected = selectedFileIndex === idx;
                
                return (
                  <button
                    key={file.path}
                    onClick={() => setSelectedFileIndex(idx)}
                    className={`w-full text-left font-mono text-xs px-3 py-2.5 rounded-lg flex items-center justify-between group transition-all duration-200 ${
                      isSelected 
                        ? "bg-sky-500/10 text-sky-300 border border-sky-500/25 font-semibold" 
                        : "text-slate-400 hover:bg-slate-800/40 hover:text-slate-200 border border-transparent"
                    }`}
                    id={`tree-file-${idx}`}
                  >
                    <div className="flex items-center gap-2 overflow-hidden">
                      <FileCode className={`h-3.5 w-3.5 shrink-0 ${isSelected ? 'text-sky-400' : 'text-slate-500 group-hover:text-slate-400'}`} />
                      <span className="truncate">{dynamicPath}</span>
                    </div>
                    <ChevronRight className={`h-3.5 w-3.5 opacity-0 group-hover:opacity-100 shrink-0 transition-opacity ${isSelected ? 'opacity-100 text-sky-400' : 'text-slate-600'}`} />
                  </button>
                );
              })}
            </div>
          </div>
        </section>

        {/* Right Side: Interactive Code Viewer + Instructions */}
        <section className="lg:col-span-8 flex flex-col gap-6">
          
          {/* Active File Code Viewer */}
          <div className="bg-slate-900/45 border border-slate-800/60 rounded-2xl shadow-xl overflow-hidden flex flex-col" id="code-viewer-panel">
            <div className="bg-slate-950/75 px-5 py-4 border-b border-slate-800/80 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div>
                <span className="text-[10px] uppercase font-bold text-sky-400 tracking-wider font-mono">
                  Active Code Preview
                </span>
                <h3 className="text-white font-mono font-medium text-sm mt-0.5 truncate flex items-center gap-2">
                  <span className="text-slate-500">Workspace / </span>
                  {currentPath}
                </h3>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => handleCopy(currentCode, currentFile.path)}
                  className="flex items-center gap-1.5 text-xs bg-slate-900 hover:bg-slate-850 text-slate-200 hover:text-white px-3.5 py-2 rounded-lg border border-slate-800 transition-all cursor-pointer"
                  id="btn-copy-code"
                >
                  {copyStatus === currentFile.path ? (
                    <>
                      <Check className="h-3.5 w-3.5 text-emerald-400 animate-pulse" />
                      <span className="text-emerald-400 font-medium">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="h-3.5 w-3.5" />
                      <span>Copy File</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            <div className="p-4 bg-slate-950/45 border-b border-slate-850">
              <p className="text-xs text-slate-400 italic">
                💡 <b className="text-slate-300 font-medium font-sans">Role:</b> {currentFile.description}
              </p>
            </div>

            {/* Code editor presentation box */}
            <div className="overflow-x-auto bg-slate-950/90 font-mono text-xs leading-relaxed max-h-[480px] overflow-y-auto">
              <pre className="p-5 overflow-auto text-slate-300 relative selection:bg-emerald-500/25">
                <code>{currentCode}</code>
              </pre>
            </div>
          </div>

          {/* Setup Orchestrator & Auto Build Tester */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Run Setup Simulator and Logs */}
            <div className="bg-slate-900/45 border border-slate-800/60 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                <div className="flex items-center gap-2">
                  <Terminal className="h-5 w-5 text-emerald-400" />
                  <h2 className="text-sm font-semibold tracking-wide text-white uppercase">CI/CD Run Simulator</h2>
                </div>
                
                <button
                  onClick={startBuildSimulation}
                  disabled={simulationActive && !simCompleted}
                  className={`flex items-center gap-1.5 text-xs font-semibold px-4 py-2 cursor-pointer rounded-lg transition-all ${
                    simulationActive && !simCompleted
                      ? "bg-slate-800 text-slate-500 cursor-not-allowed"
                      : "bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold"
                  }`}
                  id="btn-simulate-build"
                >
                  {simulationActive && !simCompleted ? (
                    <>
                      <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                      <span>Building...</span>
                    </>
                  ) : (
                    <>
                      <Play className="h-3.5 w-3.5" />
                      <span>Simulate GitHub Build</span>
                    </>
                  )}
                </button>
              </div>

              {/* Terminal Logs Simulation */}
              <div className="flex-1 min-h-[220px] max-h-[300px] bg-slate-950/95 border border-slate-850 rounded-xl p-4 font-mono text-[11px] leading-relaxed overflow-y-auto flex flex-col gap-1.5 selection:bg-sky-500/25">
                {simLogs.map((log, index) => {
                  let colorClass = "text-slate-400";
                  if (log.startsWith("🚀") || log.startsWith("✨")) colorClass = "text-emerald-400 font-bold";
                  if (log.startsWith("⚙️")) colorClass = "text-sky-400";
                  if (log.includes("$ ./gradlew")) colorClass = "text-yellow-400 font-medium";
                  if (log.startsWith("🎉")) colorClass = "text-pink-400 font-bold text-xs";
                  
                  return (
                    <div key={index} className={`${colorClass} whitespace-pre-wrap border-l-2 border-slate-800 pl-2`}>
                      {log}
                    </div>
                  );
                })}
                
                {simulationActive && !simCompleted && (
                  <div className="flex items-center gap-2 text-sky-400 text-xs mt-2 font-semibold">
                    <RefreshCw className="h-3 w-3 animate-spin" />
                    <span>Executing pipeline actions...</span>
                  </div>
                )}
                
                {simLogs.length === 1 && (
                  <div className="text-slate-500 text-center py-12 flex flex-col items-center gap-2">
                    <HelpCircle className="h-8 w-8 text-slate-700" />
                    <span>Click 'Simulate GitHub Build' to test the Android compilation steps</span>
                  </div>
                )}
              </div>
            </div>

            {/* Quick Terminal setup runner */}
            <div className="bg-slate-900/45 border border-slate-800/60 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <Terminal className="h-5 w-5 text-sky-400" />
                  <h2 className="text-sm font-semibold tracking-wide text-white uppercase">Dev Instant Bootstrapper</h2>
                </div>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">
                Create this exact structured workspace locally in 1 click! Copy our customized shell helper script, save it as <code className="font-mono text-sky-300 bg-sky-900/25 px-1 py-0.5 rounded text-[11px]">setup.sh</code>, and run it in any directory:
              </p>

              <div className="bg-slate-950 p-3 rounded-xl border border-slate-850 font-mono text-[10px] text-emerald-400/95 overflow-x-auto max-h-[140px] whitespace-pre select-all">
                {`# Copy, save to a file 'setup.sh', then execute: bash setup.sh
${generateBashScript().substring(0, 1000)}
# ... [Full script generates all subfolders and files dynamically]`}
              </div>

              <div className="flex items-center gap-2 mt-auto">
                <button
                  onClick={() => handleCopy(generateBashScript(), "bash-setup")}
                  className="w-full flex items-center justify-center gap-1.5 text-xs bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold py-2.5 rounded-lg transition-all cursor-pointer"
                  id="btn-copy-terminal-script"
                >
                  {copyStatus === "bash-setup" ? (
                    <>
                      <Check className="h-3.5 w-3.5 animate-pulse text-slate-950" />
                      <span>Launcher Script Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="h-3.5 w-3.5" />
                      <span>Copy Full Setup Shell Script</span>
                    </>
                  )}
                </button>
              </div>
            </div>
            
          </div>

          {/* Quick Guide & Deployment instructions */}
          <div className="bg-slate-900/45 border border-slate-800/60 rounded-2xl p-6 shadow-xl flex flex-col gap-5">
            <h3 className="text-white text-sm font-semibold tracking-wide uppercase border-b border-slate-800 pb-3 flex items-center gap-2">
              <BookOpen className="h-5 w-5 text-sky-400" /> Setup & Release Checklist
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs leading-relaxed text-slate-300">
              <div className="flex flex-col gap-2 p-4 bg-slate-950/40 rounded-xl border border-slate-850">
                <div className="flex items-center gap-2 text-white font-medium text-sm">
                  <span className="h-5 w-5 rounded-full bg-sky-500/10 border border-sky-400/25 text-sky-400 flex items-center justify-center font-bold text-xs">1</span>
                  <span>Push to GitHub</span>
                </div>
                <p className="text-slate-400">
                  Save all files into a local folder (matching the layout) and initialize a git repo. Link and push to your remote GitHub repository on the <code className="text-sky-300 font-mono">main</code> branch!
                </p>
              </div>

              <div className="flex flex-col gap-2 p-4 bg-slate-950/40 rounded-xl border border-slate-850">
                <div className="flex items-center gap-2 text-white font-medium text-sm">
                  <span className="h-5 w-5 rounded-full bg-sky-500/10 border border-sky-400/25 text-sky-400 flex items-center justify-center font-bold text-xs">2</span>
                  <span>Push version tags</span>
                </div>
                <p className="text-slate-400">
                  Whenever you wrap a code version, create a tag on terminal:
                  <code className="block bg-slate-950 text-emerald-400 text-[10px] p-1 rounded font-mono mt-1">git tag v1.0.0</code>
                  <code className="block bg-slate-950 text-emerald-400 text-[10px] p-1 rounded font-mono mt-0.5">git push origin v1.0.0</code>
                </p>
              </div>

              <div className="flex flex-col gap-2 p-4 bg-slate-950/40 rounded-xl border border-slate-850">
                <div className="flex items-center gap-2 text-white font-medium text-sm">
                  <span className="h-5 w-5 rounded-full bg-sky-500/10 border border-sky-400/25 text-sky-400 flex items-center justify-center font-bold text-xs">3</span>
                  <span>Fetch Your APK</span>
                </div>
                <p className="text-slate-400">
                  Navigate to the <span className="text-white font-semibold flex inline-flex items-center gap-0.5">Releases <ExternalLink className="h-2.5 w-2.5" /></span> page or <span className="text-white font-semibold">Actions</span>. The signed Android package will be compiled, checked and instantly attached to the version tag.
                </p>
              </div>
            </div>
          </div>

        </section>

      </main>

      {/* Footer copyright */}
      <footer className="border-t border-slate-900 bg-slate-950/80 py-5 text-center px-4 font-mono text-[10px] text-slate-500 mt-10">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <span>Android GitHub Release Boilerplate Builder</span>
          <span className="flex items-center gap-1.5 justify-center">
            <Github className="h-3 w-3" /> Guaranteed build compatible on standard actions runners.
          </span>
        </div>
      </footer>
    </div>
  );
}
